#include <stdio.h>
#include <string.h>
#include "globals.h"
#include "storage.h"

// Writes all program data (Doctors and Appointments) to a text file.
// Serialization - converting memory structures into text format.

void saveData() {
    // Open file in "w" (Write) mode.
    FILE *fp = fopen(DATA_FILE, "w");
    if (fp == NULL) {
        printf("Error: Could not save to file!\n");
        return;
    }


    // SAVE DOCTORS

    // First, write the total number of doctors.
    // This allows loadData() to know how many loops to run later.
    fprintf(fp, "%d\n", doctorCount);

    for (int i = 0; i < doctorCount; i++) {
        fprintf(fp, "%d\n", doctors[i].id);
        fprintf(fp, "%s\n", doctors[i].name);
        fprintf(fp, "%s\n", doctors[i].specialty);
    }

    // SAVE APPOINTMENTS

    // Write the total number of appointments
    fprintf(fp, "%d\n", appointmentCount);

    for (int i = 0; i < appointmentCount; i++) {
        fprintf(fp, "%d\n", appointments[i].id);
        fprintf(fp, "%d\n", appointments[i].doctorId); // Foreign Key logic
        fprintf(fp, "%s\n", appointments[i].patientName); // Save the patient name
        fprintf(fp, "%s\n", appointments[i].phone); // Save the phone number
        fprintf(fp, "%s\n", appointments[i].date); // Save the appointment date
        fprintf(fp, "%s\n", appointments[i].time); // Save the appointment time
    }

    // Always close the file to ensure data is physically written to disk
    fclose(fp);
}


// Reads data from the text file at startup and restores the state.
void loadData() {
    // Open file in "r" (Read) mode
    FILE *fp = fopen(DATA_FILE, "r");

    // If file doesn't exist (first program run), just return.
    if (fp == NULL) return;


    // LOAD DOCTORS

    // Read the count. If checking fails (file empty/corrupt), stop.
    if (fscanf(fp, "%d", &doctorCount) != 1) { fclose(fp); return; }
    fgetc(fp); // Consume the newline character left after reading the number

    for (int i = 0; i < doctorCount; i++) {
        fscanf(fp, "%d", &doctors[i].id);
        fgetc(fp); // Skip newline after ID

        // Use fgets for strings with spaces (Names, Specialties)
        fgets(doctors[i].name, STR_LEN, fp);
        // Remove the trailing newline character '\n' added by fgets
        doctors[i].name[strcspn(doctors[i].name, "\n")] = 0;

        fgets(doctors[i].specialty, STR_LEN, fp);
        doctors[i].specialty[strcspn(doctors[i].specialty, "\n")] = 0;
    }

    // LOAD APPOINTMENTS

    if (fscanf(fp, "%d", &appointmentCount) != 1) { fclose(fp); return; }
    fgetc(fp); // Consume newline

    for (int i = 0; i < appointmentCount; i++) {
        fscanf(fp, "%d", &appointments[i].id);
        fscanf(fp, "%d", &appointments[i].doctorId);
        fgetc(fp); // Skip newline

        fgets(appointments[i].patientName, STR_LEN, fp);
        appointments[i].patientName[strcspn(appointments[i].patientName, "\n")] = 0;

        // Load the phone number
        // Phone numbers usually don't have spaces, so simple fscanf works
        fscanf(fp, "%s", appointments[i].phone);

        fscanf(fp, "%s", appointments[i].date);
        fscanf(fp, "%s", appointments[i].time);
        fgetc(fp); // Consume remaining newline
    }

    fclose(fp);
}