#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h> // Required for isdigit()
#include <time.h>  // Required for date comparison
#include "globals.h"
#include "storage.h"
#include "doctors.h" // Required to call listDoctors()
#include "appointments.h"

// HELPER FUNCTIONS (VALIDATION)

// Helper function to check if a date is in the past.
// Returns 1 if the date is invalid or in the past, 0 if it is valid (future/today).
int isDateInPast(char *dateStr) {
    int d, m, y;
    // Parse the string "DD.MM.YYYY" into integers
    if (sscanf(dateStr, "%d.%d.%d", &d, &m, &y) != 3) return 1; // Invalid format

    // Get current local time
    time_t now = time(NULL);
    struct tm *current = localtime(&now);

    int curDay = current->tm_mday;
    int curMonth = current->tm_mon + 1; // tm_mon is 0-11, so we add 1
    int curYear = current->tm_year + 1900; // tm_year is years since 1900

    // Compare years, then months, then days
    if (y < curYear) return 1; // Past year
    if (y == curYear && m < curMonth) return 1; // Past month this year
    if (y == curYear && m == curMonth && d < curDay) return 1; // Past day this month

    return 0; // Date is valid
}

// Regex-style validation for Time (Format: HH:MM)
// Checks if the string matches the pattern and if hours/minutes are realistic.
int isValidTimeFormat(char *timeStr) {
    // Length must be exactly 5 ("09:00")
    if (strlen(timeStr) != 5) return 0;
    // Third character must be a colon
    if (timeStr[2] != ':') return 0;
    // Ensure all other characters are digits
    if (!isdigit(timeStr[0]) || !isdigit(timeStr[1])) return 0;
    if (!isdigit(timeStr[3]) || !isdigit(timeStr[4])) return 0;

    int hh = atoi(timeStr); // Parse hours
    int mm = atoi(&timeStr[3]); // Parse minutes

    if (hh < 0 || hh > 23) return 0; // Invalid hour
    if (mm < 0 || mm > 59) return 0; // Invalid minute

    return 1; // Time is valid
}

// Validate phone number (10 digits)
int isValidPhone(char *phone) {
    int len = strlen(phone);
    if (len != 10) return 0;
    for(int i = 0; i < len; i++) {
        if(!isdigit(phone[i])) return 0;
    }
    return 1;
}



// Handles the logic for scheduling a new appointment.
// Includes collision detection to prevent double-booking.
void bookAppointment() {
    int docId, foundIndex = -1;
    char date[15], time[10], pName[50], phone[20];
    char buffer[100]; // Buffer for handling "0" input (Back navigation)

    // Validation: Check if there are doctors in the system
    if (doctorCount == 0) {
        printf("Error: Please add a doctor first.\n");
        return;
    }

    // Select a Doctor
    listDoctors();
    
    // Navigation - Allow user to go back
    printf("\nEnter Doctor ID (or 0 to go back): ");
    scanf("%s", buffer);
    if (strcmp(buffer, "0") == 0) return; // Exit function if 0 is entered
    
    docId = atoi(buffer); // Convert input to integer
    getchar(); // Clear buffer

    // Verify if the doctor exists
    for(int i = 0; i < doctorCount; i++) {
        if(doctors[i].id == docId) foundIndex = i;
    }

    if(foundIndex == -1) {
        printf("Error: Doctor with ID %d not found!\n", docId);
        return;
    }

    // Date Selection with Validation
    while(1) {
        printf("Enter Date (DD.MM.YYYY) or 0 to back: ");
        scanf("%s", date);
        if (strcmp(date, "0") == 0) return;

        // Check if date is in the past
        if (isDateInPast(date)) {
            printf("Error: Date is in the past or invalid format! Try again.\n");
        } else {
            break; // Date is good, exit loop
        }
    }

    // Time Selection with Regex-style Validation
    while(1) {
        printf("Enter Time (HH:MM) or 0 to back: ");
        scanf("%s", time);
        if (strcmp(time, "0") == 0) return;

        // Check strict format
        if (!isValidTimeFormat(time)) {
            printf("Error: Invalid time format! Use HH:MM (e.g., 14:30).\n");
        } else {
            // Availability Check (Collision Detection)
            int busy = 0;
            for (int i = 0; i < appointmentCount; i++) {
                if (appointments[i].doctorId == docId &&
                    strcmp(appointments[i].date, date) == 0 &&
                    strcmp(appointments[i].time, time) == 0) {
                    busy = 1;
                }
            }
            
            if (busy) {
                printf("Error: Selected slot is BUSY! Please choose another time.\n");
            } else {
                break; // Time is free and valid, exit loop
            }
        }
    }

    getchar(); // Clear buffer before reading string with spaces

    // Enter Patient Name
    printf("Enter Patient Name (or 0 to back): ");
    scanf("%[^\n]s", pName);
    getchar();
    if (strcmp(pName, "0") == 0) return;

    // Enter Phone Number
    while(1) {
        printf("Enter Phone (10 digits) or 0 to back: ");
        scanf("%s", phone);
        if (strcmp(phone, "0") == 0) return;

        if (!isValidPhone(phone)) {
            printf("Error: Phone must contain exactly 10 digits!\n");
        } else {
            break;
        }
    }

    // Add new appointment to the global array
    appointments[appointmentCount].id = appointmentCount + 1; // Simple Auto-ID
    appointments[appointmentCount].doctorId = docId;
    strcpy(appointments[appointmentCount].date, date);
    strcpy(appointments[appointmentCount].time, time);
    strcpy(appointments[appointmentCount].patientName, pName);
    strcpy(appointments[appointmentCount].phone, phone); // Save phone

    appointmentCount++; // Increment the total count

    saveData(); // Persist data to file
    printf("Successfully booked appointment for %s (Tel: %s)!\n", pName, phone);
}


// Filters and displays appointments for a specific doctor.
void viewSchedule() {
    int docId;
    char buffer[20];

    listDoctors();
    if(doctorCount == 0) return;

    // Allow "0" to go back
    printf("\nEnter Doctor ID to view schedule (or 0 to back): ");
    scanf("%s", buffer);
    if(strcmp(buffer, "0") == 0) return;
    
    docId = atoi(buffer);
    getchar();

    printf("\n--- Schedule for Dr. ID %d ---\n", docId);
    printf("%-12s | %-8s | %-20s | %-15s\n", "Date", "Time", "Patient", "Phone");
    printf("------------------------------------------------------------\n");

    int found = 0;
    // Iterate through all appointments and print only those matching the doctor ID
    for(int i = 0; i < appointmentCount; i++) {
        if(appointments[i].doctorId == docId) {
            printf("%-12s | %-8s | %-20s | %-15s\n",
                   appointments[i].date,
                   appointments[i].time,
                   appointments[i].patientName,
                   appointments[i].phone); // Print phone
            found = 1;
        }
    }

    if(!found) {
        printf("No appointments found for this doctor.\n");
    }
}


// Deletes an appointment by Patient Name
void cancelAppointment() {
    char nameToDelete[50];
    int foundIndex = -1;

    printf("\n--- Cancel Appointment ---\n");
    printf("Enter Patient Name to cancel (or 0 to back): ");
    scanf("%[^\n]s", nameToDelete);
    getchar();
    
    // Navigation Check
    if (strcmp(nameToDelete, "0") == 0) return;

    // Linear Search: Find the index by matching Patient Name
    // If there are duplicate names, this simple logic deletes the first one found.
    for(int i = 0; i < appointmentCount; i++) {
        if(strcmp(appointments[i].patientName, nameToDelete) == 0) {
            foundIndex = i;
            break; // Stop after finding the first match
        }
    }

    if(foundIndex == -1) {
        printf("Error: Appointment for patient '%s' not found!\n", nameToDelete);
        return;
    }

    // Display confirmation details
    printf("Deleting appointment for %s on %s at %s...\n", 
           appointments[foundIndex].patientName, 
           appointments[foundIndex].date, 
           appointments[foundIndex].time);

    // Array Shifting Algorithm (Deletion)
    // To delete an element in an array, we must move all subsequent elements
    // one position to the left to fill the gap.
    for(int i = foundIndex; i < appointmentCount - 1; i++) {
        appointments[i] = appointments[i+1];
    }

    appointmentCount--; // Decrease the total count of appointments
    saveData(); // Update the file

    printf("Success! Appointment cancelled.\n");
}