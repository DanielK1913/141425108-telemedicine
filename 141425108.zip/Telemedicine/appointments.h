#ifndef APPOINTMENTS_H
#define APPOINTMENTS_H

void bookAppointment();
void viewSchedule();
void cancelAppointment();
#endif
