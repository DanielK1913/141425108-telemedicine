#ifndef STORAGE_H
#define STORAGE_H

void saveData();
void loadData();

#endif
