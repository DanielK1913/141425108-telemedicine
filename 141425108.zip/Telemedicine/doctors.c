#include <stdio.h>
#include "globals.h"
#include "storage.h" // Required to access the saveData() function
#include "doctors.h"

// addDoctor
// Collects input for a new doctor and saves it to the database.

void addDoctor() {
    // Boundary Check
    // Ensure we don't exceed the array limit defined in globals.h
    if (doctorCount >= MAX_DOCTORS) {
        printf("Error: Max doctor capacity reached!\n");
        return;
    }

    Doctor newDoc;
    printf("\n--- Add New Doctor ---\n");

    // Input ID
    printf("Enter ID (numeric): ");
    scanf("%d", &newDoc.id);
    getchar(); // Consumes the newline character left by scanf

    // Input Name
    // We use "%[^\n]s" to read the whole line including spaces
    // Standard %s stops reading at the first space.
    printf("Enter Name: ");
    scanf("%[^\n]s", newDoc.name);
    getchar(); // Consume the newline again

    // Input Specialty
    printf("Enter Specialty: ");
    scanf("%[^\n]s", newDoc.specialty);
    getchar();

    // Add to Global Array
    // Store the new structure in the array and increment the counter
    doctors[doctorCount++] = newDoc;

    // Persistence
    // Save to file immediately so data isn't lost if the program closes
    saveData();
    printf("Success! Doctor added and saved.\n");
}

// listDoctors
// Displays all registered doctors in a formatted table.
void listDoctors() {
    printf("\n--- Doctors List ---\n");

    // Check if the database is empty
    if (doctorCount == 0) {
        printf("No doctors found in the system.\n");
        return;
    }

    // Print Table Header
    // %-5s means: Print a string, take up at least 5 spaces, align left.
    // %-20s means: Take up 20 spaces, align left.
    printf("%-5s | %-20s | %-20s\n", "ID", "Name", "Specialty");
    printf("--------------------------------------------------\n");

    // Loop through the array and print each doctor's details
    for (int i = 0; i < doctorCount; i++) {
        printf("%-5d | %-20s | %-20s\n",
               doctors[i].id,
               doctors[i].name,
               doctors[i].specialty);
    }
}
