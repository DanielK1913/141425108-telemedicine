#ifndef DOCTORS_H
#define DOCTORS_H

void addDoctor();
void listDoctors();

#endif