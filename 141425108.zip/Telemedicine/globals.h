#ifndef GLOBALS_H
#define GLOBALS_H

// CONSTANTS
#define MAX_DOCTORS 50
#define MAX_APPOINTMENTS 100
#define STR_LEN 50
#define DATA_FILE "telemedicine_data.txt"

// DATA STRUCTURES
typedef struct {
    int id;
    char name[STR_LEN];
    char specialty[STR_LEN];
} Doctor;

typedef struct {
    int id;
    int doctorId;
    char patientName[STR_LEN];
    char phone[20]; // patient phone number
    char date[15]; // petient date appointment
    char time[10]; // petient time for appointment
} Appointment;


// globals.h allows other files to access these variables.
extern Doctor doctors[MAX_DOCTORS];
extern int doctorCount;

extern Appointment appointments[MAX_APPOINTMENTS];
extern int appointmentCount;

#endif