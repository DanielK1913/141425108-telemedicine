#include <stdio.h>
#include <stdlib.h>
#include "globals.h"
#include "doctors.h"
#include "appointments.h"
#include "storage.h"


// GLOBAL VARIABLES DEFINITION
// This is where memory is actually allocated for the arrays
Doctor doctors[MAX_DOCTORS];
int doctorCount = 0;

Appointment appointments[MAX_APPOINTMENTS];
int appointmentCount = 0;

// MAIN FUNCTION
int main() {
    int choice;

    // Load Data Persistence
    // Read data from the text file immediately when the program starts
    // This ensures we don't lose records from previous sessions
    loadData();

    // Start the main program loop
    do {
        // Display the Main Menu
        
        printf("\n====================================\n");
        printf("    TELEMEDICINE SCHEDULER SYSTEM\n");
        printf("====================================\n");
        printf("1. Add New Doctor\n");
        printf("2. List All Doctors\n");
        printf("3. Book Appointment\n");
        printf("4. View Doctor Schedule\n");
        printf("5. Cancel Appointment\n"); 
        printf("0. Exit\n");
        printf("------------------------------------\n");
        printf("Enter your choice: ");

        // Input Validation
        // scanf returns the number of successfully read items.
        // If it returns 0, the user entered text instead of a number.
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input! Please enter a valid number.\n");

            // Clear the input buffer to prevent an infinite loop
            while(getchar() != '\n');

            choice = -1; // Force the loop to continue
            continue;
        }
        getchar(); // Consume the trailing newline character

        // Menu Navigation
        // Call the appropriate function based on user input
        switch(choice) {
            case 1:
                addDoctor();
                break;
            case 2:
                listDoctors();
                break;
            case 3:
                bookAppointment();
                break;
            case 4:
                viewSchedule();
                break;
            case 5:
                cancelAppointment(); // Function to delete an appointment
                break;
            case 0:
                printf("Exiting system. Goodbye!\n");
                break;
            default:
                printf("Invalid choice! Try again.\n");
        }

    } while (choice != 0); // Keep running until the user enters 0

    return 0;
}